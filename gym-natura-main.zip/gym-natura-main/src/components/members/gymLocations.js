export const gymLocations = [
  {
    id: "1",
    image:
      "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80",
    heading: "maddison garden",
    desc: "Our Maddison Garden location is ideal for women who want to get outdoors and enjoy some fresh air while they work out.",
  },
  {
    id: "2",
    image:
      "https://images.unsplash.com/photo-1621293954908-907159247fc8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80",
    heading: "blairgrove",
    desc: "The Blairgrove location is perfect for women who want to feel pampered while they exercise.",
  },
];
